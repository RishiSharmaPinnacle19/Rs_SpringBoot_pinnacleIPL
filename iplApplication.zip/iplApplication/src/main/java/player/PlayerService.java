package player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import Team.Team;

public class PlayerService {
	
	private static final List<player.Player> Player = null;
	Team team1 = new Team("t1", "Mumbai Indians", "Mukesh Ambani");
    Team team2 = new Team("t2", "Delhi Capitals", "GMR Group");

    Player player1 = new Player("p1", "Rohit Sharma", "Indian", "Batsman", team1);
    Player player2 = new Player("p2", "Shreyas Iyer", "Indian", "Batsman", team2);

    List<Player> players = new ArrayList<>(Arrays.asList(player1, player2));

    public List<Player> getAllPlayers() {
        return Player;
    }

    public Player getPlayer(String id) {
        for (Player player : Player) {
            if (player.getName().equals(id)) {  // Now comparing based on PlayerName
                return player;
            }
        }
        return null;
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public void deletePlayer(String id) {
        players.removeIf(player -> player.getId().equals(id));  // Remove player by ID
    }

    public void updatePlayer(String id, Player updatedPlayer) {
        for (int i = 0; i < players.size(); i++) {
            if (Player.get(i).getId().equals(id)) {  // Compare using Player ID
                Player.set(i, updatedPlayer);  // Update the player
                break;  // Exit after updating
            }
        }
    }


}
