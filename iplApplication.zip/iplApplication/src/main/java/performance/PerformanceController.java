package performance;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/performance") // RESTful route naming convention
public class PerformanceController {

    @Autowired
    private PerformanceService performanceService;

    // Get all performances
    @GetMapping
    public List<Performance> getAllPerformances() {
        return performanceService.getAllPerformances();
    }

    // Get performance by ID
    @GetMapping("/{id}")
    public Performance getPerformance(@PathVariable String id) {
        return performanceService.getPerformance(id);
    }

    // Add a new performance
    @PostMapping
    public void addPerformance(@RequestBody Performance performance) {
        performanceService.addPerformance(performance);
    }

    // Update performance by ID
    @PutMapping("/{id}")
    public void updatePerformance(@PathVariable String id, @RequestBody Performance performance) {
        performanceService.updatePerformance(id, performance);
    }

    // Delete performance by ID
    @DeleteMapping("/{id}")
    public void deletePerformance(@PathVariable String id) {
        performanceService.deletePerformance(id);
    }
}
