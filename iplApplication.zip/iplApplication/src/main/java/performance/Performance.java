package performance;

import com.pinnacle.iplApplication.Match.Match;

import player.Player;



public class Performance {
	  private String performanceId;
	    private int runs;
	    private int balls;
	    private int wickets;
	    private float overs;
	    private Player player;
	    private Match matchId;
		public Performance(String performanceId, int runs, int balls, int wickets, float overs, Player player,Match matchId) {
			super();
			this.performanceId = performanceId;
			this.runs = runs;
			this.balls = balls;
			this.wickets = wickets;
			this.overs = overs;
			this.player = player;
			this.matchId = matchId;
		}
		public String getPerformanceId() {
			return performanceId;
		}
		public void setPerformanceId(String performanceId) {
			this.performanceId = performanceId;
		}
		public int getRuns() {
			return runs;
		}
		public void setRuns(int runs) {
			this.runs = runs;
		}
		public int getBalls() {
			return balls;
		}
		public void setBalls(int balls) {
			this.balls = balls;
		}
		public int getWickets() {
			return wickets;
		}
		public void setWickets(int wickets) {
			this.wickets = wickets;
		}
		public float getOvers() {
			return overs;
		}
		public void setOvers(float overs) {
			this.overs = overs;
		}
		public Player getPlayer() {
			return player;
		}
		public void setPlayer(Player player) {
			this.player = player;
		}
		public Match getMatchId() {
			return matchId;
		}
		public void setMatchId(Match matchId) {
			this.matchId = matchId;
		}

}
