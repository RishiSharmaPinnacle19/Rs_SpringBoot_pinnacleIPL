package performance;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.pinnacle.iplApplication.Match.Match;

import Team.Team;
import player.Player;


import org.springframework.stereotype.Service;



@Service
public class PerformanceService {
	
	  Team team1 = new Team("t1", "Mumbai Indians", "Mukesh Ambani");
	    Team team2 = new Team("t2", "Delhi Capitals", "GMR Group");

	    Player player1 = new Player("p1", "Rohit Sharma", "India", "Batsman", team1);
	    Player player2 = new Player("p2", "Shreyas Iyer", "India", "Allrounder", team2);
	    Match m1 = new Match("m1", "01-Jan-2025", "Wankhede Stadium", new Team("t1", "Mumbai Indians", "Mukesh Ambani"), new Team("t2", "Delhi Capitals", "GMR Group"), "Mumbai Wins");
	    Match m2 = new Match("m2", "01-Jan-2025", "Wankhede Stadium", new Team("t1", "Mumbai Indians", "Mukesh Ambani"), new Team("t2", "Delhi Capitals", "GMR Group"), "Mumbai Wins");

	    Performance performance1 = new Performance("perf1", 75,55, 0,10.0f, player1, m1);
	    Performance performance2 = new Performance("perf2", 50, 45, 2 ,8.2f, player2, m2);

	    List<Performance> performances = new ArrayList<>(Arrays.asList(performance1, performance2));

	    public List<Performance> getAllPerformances() {
	        return performances;
	    }

	    public Performance getPerformance(String performanceId) {
	        for (Performance performance : performances) {
	            if (performance.getPerformanceId().equals(performanceId)) {
	                return performance;
	            }
	        }
	        return null;
	    }

	    public void addPerformance(Performance performance) {
	        performances.add(performance);
	    }

	    public void deletePerformance(String id) {
	        performances.removeIf(performance -> performance.getPerformanceId().equals(id));  // Remove performance by ID
	    }
	    public void updatePerformance(String performanceId, Performance updatedPerformance) {
	        for (int i = 0; i < performances.size(); i++) {
	            if (performances.get(i).getPerformanceId().equals(performanceId)) {  // Compare using Performance ID
	                performances.set(i, updatedPerformance);  // Update the performance
	                break;  // Exit after updating
	            }
	        }
	    }


}
