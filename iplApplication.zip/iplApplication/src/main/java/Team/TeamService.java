package Team;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TeamService {

	   Team team1 = new Team("t1", "Mumbai Indians", "Mukesh Ambani");
	    Team team2 = new Team("t2", "Delhi Capitals", "GMR Group");
	    Team team3 = new Team("t3", "Royal Challengers Bangalore", "Vijay Mallya");

	    List<Team> teams = new ArrayList<>(Arrays.asList(team1, team2, team3));

	    public List<Team> getAllTeams() {
	        return teams;
	    }

	    public Team getTeam(String id) {
	        for (Team team : teams) {
	            if (team.getTeamName().equals(id)) {  // Now comparing based on TeamName
	                return team;
	            }
	        }
	        return null;
	    }

	    public void addTeam(Team team) {
	        teams.add(team);
	    }

	    public void deleteTeam(String id) {
	        teams.removeIf(team -> team.getTeamID().equals(id));  // Remove team by ID
	    }

	    public void updateTeam(String id, Team updatedTeam) {
	        for (int i = 0; i < teams.size(); i++) {
	            if (teams.get(i).getTeamID().equals(id)) {  // Compare based on Team ID
	                teams.set(i, updatedTeam);
	            }
	        }
	    }

	
}
