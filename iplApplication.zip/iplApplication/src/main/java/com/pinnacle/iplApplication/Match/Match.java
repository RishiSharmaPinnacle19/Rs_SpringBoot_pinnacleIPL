package com.pinnacle.iplApplication.Match;

import Team.Team;

public class Match {
    private String matchId;
    private String date;
    private String venue;
    private Team team1;
    private Team team2;
    private String result;

    // Constructor
    public Match(String matchId, String date, String venue, Team team1, Team team2, String result) {
        this.matchId = matchId;
        this.date = date;
        this.venue = venue;
        this.team1 = team1;
        this.team2 = team2;
        this.result = result;
    }

    // Getters and Setters
    public String getMatchId() {
        return matchId;
    }

    public void setMatchId(String matchId) {
        this.matchId = matchId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public Team getTeam1() {
        return team1;
    }

    public void setTeam1(Team team1) {
        this.team1 = team1;
    }

    public Team getTeam2() {
        return team2;
    }

    public void setTeam2(Team team2) {
        this.team2 = team2;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
       
    	this.result = result;
    }
}