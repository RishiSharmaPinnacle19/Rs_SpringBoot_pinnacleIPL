package com.pinnacle.iplApplication.Match;
import Team.Team;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;


@Service
public class MatchService {


	
    Team team1 = new Team("t1", "Mumbai Indians", "Mukesh Ambani");
    Team team2 = new Team("t2", "Delhi Capitals", "GMR Group");

    Match match1 = new Match("m1", "01-Jan-2025", "Wankhede Stadium", team1, team2, "Mumbai Wins");
    Match match2 = new Match("m2", "02-Jan-2025", "Feroz Shah Kotla", team2, team1, "Delhi Wins");

    List<Match> matches = new ArrayList<>(Arrays.asList(match1, match2));

    public List<Match> getAllMatches() {
        return matches;
    }

    public Match getMatch(String id) {
        for (Match match : matches) {
            if (match.getVenue().equals(id)) {  // Using 'venue' for comparison instead of 'getId()'
                return match;
            }
        }
        return null;
    }

    public void addMatch(Match match) {
        matches.add(match);
    }

    public void deleteMatch(String id) {
        matches.removeIf(match -> match.getMatchId().equals(id));  // Remove match by ID
    }

    public void updateMatch(String id, Match updatedMatch) {
        for (int i = 0; i < matches.size(); i++) {
            if (matches.get(i).getMatchId().equals(id)) {  // Compare using Match ID
                matches.set(i, updatedMatch);  // Update the match
                break;  // Exit after updating
            }
        }
    }

}
